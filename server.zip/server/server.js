const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: [
      "http://localhost:3000",
      "https://unarticulated-unnecessitously-toccara.ngrok-free.dev"
    ],
    methods: ["GET", "POST"]
  }
});


// Store document content
let documentContent = '';

io.on('connection', (socket) => {
  console.log('A user connected');

  // Send current content to new users
  socket.emit('init-document', documentContent);

  // Handle text changes
  socket.on('text-change', (newContent) => {
    documentContent = newContent;
    socket.broadcast.emit('text-update', newContent);
  });

  socket.on('disconnect', () => {
    console.log('A user disconnected');
  });
});

const PORT = process.env.PORT || 5001;  // Changed to port 5001
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});